mod_1_update_ui <- function(id, session, settings){

  #### VARIABLES

  cooperationForm <- c("None",
                       "Played in band",
                       "Played with another musician",
                       "Played with another band")

  coopCond <- cooperationForm[3:4]

  ns <- NS(id)

  tags$table(style = "width: 95%;",
             tags$tr(style = "height: 85%;",
                     tags$td(id = "left_1", ### input
                             h2(icon("gear"), "Settings"),
                             shinyWidgets::radioGroupButtons(inputId = ns('performer_type_1'),
                                               label = 'Select performer type',
                                               choices = settings$performerType,
                                               status = "primary",
                                               checkIcon = list(
                                                 yes = icon("ok",
                                                            lib = "glyphicon"),
                                                 no = icon("remove",
                                                           lib = "glyphicon"))),
                             shiny::textInput(inputId = ns("performer_name_1"),
                                       label = "Enter performer's name",
                                       value = ""),
                             shinyBS::bsTooltip(ns("performer_name_1"),
                                       HTML(paste0("<b>It is strongly recommended to introduce first a family name,",
                                                   br(),
                                                   "then a given name with a comma as separator.</b>")),
                                       "right",
                                       options = list(container = "body")),
                             shiny::conditionalPanel(paste0("input['",
                                                     ns("performer_type_1"),
                                                     "'] == 'Musician'"),
                                              shinyWidgets::radioGroupButtons(inputId = ns('cooperation_form_1_1'),
                                                                label = "Select cooperation form",
                                                                choices = cooperationForm[1:3],
                                                                selected = "None",
                                                                status = "primary",
                                                                checkIcon = list(
                                                                  yes = icon("ok",
                                                                             lib = "glyphicon"),
                                                                  no = icon("remove",
                                                                            lib = "glyphicon"))),
                                              shiny::conditionalPanel(paste0("input['",
                                                                      ns("cooperation_form_1_1"),
                                                                      "'] != 'None'"),
                                                               shiny::textInput(inputId = ns("cooperator_name_1_1"),
                                                                         label = "Enter cooperator name",
                                                                         value =""),
                                                               shinyBS::bsTooltip(ns("cooperator_name_1_1"),
                                                                         HTML(paste0("<b>It is strongly recommended to introduce first a family name,",
                                                                                     br(),
                                                                                     "then a given name with a comma as separator.</b>")),
                                                                         "right",
                                                                         options = list(container = "body")))),
                             shiny::conditionalPanel(paste0("input['",
                                                     ns("performer_type_1"),
                                                     "'] =='Band'"),
                                              shinyWidgets::radioGroupButtons(inputId = ns('cooperation_form_1_2'),
                                                                label = "Select cooperation form",
                                                                choices = cooperationForm[c(1,4)],
                                                                selected = "None",
                                                                status = "primary",
                                                                checkIcon = list(
                                                                  yes = icon("ok",
                                                                             lib = "glyphicon"),
                                                                  no = icon("remove",
                                                                            lib = "glyphicon"))),
                                              shiny::conditionalPanel(paste0("input['",
                                                                      ns("cooperation_form_1_2"),
                                                                      "'] != 'None'"),
                                                               shiny::textInput(inputId = ns("cooperator_name_1_2"),
                                                                         label = "Enter cooperator name",
                                                                         value = "")
                                              )
                             ),
                             shinyWidgets::actionBttn(inputId=ns("insertion_1"),
                                        label = "Insert introduced data into table",
                                        style = "gradient",
                                        color = "primary",
                                        icon = icon("table")),
                             shinyBS::bsTooltip(ns("insertion_1"), HTML(paste0("<b>You have to click to save the introduced data.",
                                                                      br(),
                                                                      "Otherwise you will lose it :(</b>")),
                                       "right", options = list(container = "body")),
                             br(),
                             br(),
                             shinyWidgets::actionBttn(inputId=ns("transmission_1"),
                                        label = "Transfer table",
                                        style = "gradient",
                                        color = "primary",
                                        icon = icon("paper-plane")),
                             shinyBS::bsTooltip(ns("transmission_1"), HTML(paste0("<b>You have to click to send the introduced data.",
                                                                         br(),
                                                                         "Otherwise there will be no action :)</b>")),
                                       "right", options = list(container = "body"))),
                     tags$td(id = "right_1", ### output
                             DT::dataTableOutput(ns("insertion_table_1")),
                             shinyBS::bsTooltip(ns("insertion_table_1"),  HTML(paste0("<b>You can sort the table by columns, both increasingly and decreasingly.",
                                                                             br(),
                                                                             "Row filtering is also possible in the window ",
                                                                             "&#39;",
                                                                             "Search",
                                                                             "&#39;",
                                                                             "</b>")),
                                       "top", options = list(container = "body")),
                             h1(shiny::htmlOutput(ns("text_info_1")))
                     )
             )
  )




}

