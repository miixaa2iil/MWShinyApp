mod_2_retrieve_server <- function(id){
  moduleServer(id,
               function(input, output, session){


                 output$relation_table_2 <- NULL
                 output$text_info_2 <- NULL


                 ### Table creation
                 observeEvent(input$relations_2, {
                   if(is.null(performers)){
                     output$relation_table_2 <- NULL
                     output$text_info_2 <- shiny::renderText({HTML(paste0("<b>Please, select at least one performer</b>"))})
                   }else{
                     output$text_info_2 <- NULL
                     output$relation_table_2 <- DT::renderDataTable({DT::datatable(import_data(conn = settings$myDB,
                                                                                               my_table = settings$myTable,
                                                                                               performer_names = isolate(input$performers_names_2)) %>% dplyr::group_by(`Selected performer`) %>% dplyr::mutate(groupColor = (dplyr::cur_group_id()-1) %% settings$grColLen) %>% dplyr::ungroup(),
                                                                                   rownames = TRUE,
                                                                                   options = list(
                                                                                     pageLength = 20,
                                                                                     columnDefs = list(list(visible=FALSE,
                                                                                                            targets=4
                                                                                     )
                                                                                     )
                                                                                   )
                     )  %>% formatStyle(4,
                                        target='row',
                                        fontWeight = 'bold',
                                        backgroundColor = styleEqual(0:(settings$grColLen-1),
                                                                     settings$groupColors)
                     )
                     })
                   }

                 })
                 ###

               }   )}
