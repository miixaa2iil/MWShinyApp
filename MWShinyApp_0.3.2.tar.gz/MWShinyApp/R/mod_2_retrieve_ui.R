mod_2_retrieve_ui <- function(id, settings){

    ns <- NS(id)
    tags$table(style = "width: 95%;",
               tags$tr(style = "height: 85%;",
                       tags$td(id = "left_2", ### input
                               h2(icon("gear"), "Settings"),
                                                shinyWidgets::pickerInput(inputId = ns("performers_names_2"),
                                                            label = "Select or enter musicians' names",
                                                            choices =   get_performers(settings$myDB, settings$my_table) %>% dplyr::group_by("performerType") %>% dplyr::group_split(),
                                                            multiple = TRUE,
                                                            options = list(`actions-box` = TRUE)
                                                ),
                               shinyWidgets::actionBttn(inputId=ns("relations_2"),
                                          label = "Retrieve relations",
                                          style = "gradient",
                                          color = "primary",
                                          icon = icon("link")
                               ),
                               shinyBS::bsTooltip(ns("relations_2"), HTML(paste0("<b>After the selection click me",
                                                                        br(),
                                                                        "to retrieve performers", "&#39;", " relations :)</b>")),
                                         "right", options = list(container = "body"))
                               ),
                       tags$td(id="right_2", ### output
                               DT::dataTableOutput(ns("relation_table_2")),
                               bsTooltip(ns("relation_table_2"),  HTML(paste0("<b>You can sort the table by columns, both increasingly and decreasingly.",
                                                                              br(),
                                                                              "Row filtering is also possible in the window ",
                                                                              "&#39;",
                                                                              "Search",
                                                                              "&#39;",
                                                                              "</b>")),
                                         "top", options = list(container = "body")),
                               h1(shiny::htmlOutput(ns("text_info_2")))
                       )))
  }





