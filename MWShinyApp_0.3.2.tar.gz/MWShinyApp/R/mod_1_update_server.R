### SERVER

mod_1_update_server <- function(id, parent_session){
  moduleServer(id,
               function(input, output, session){

                 #### Data frame of new data
                 insDf <- reactiveValues(df = NULL)

                 ### warning info or transfer status
                 text_Info <- NULL

                 #### memory reservation of output
                 output$insertion_table_1 <- NULL
                 output$text_info_1 <- NULL

                 #### Data upload
                 observeEvent(input$insertion_1, {
                   if(input$performer_name_1 == ""){ # first warning
                     output$text_info_1 <- renderText({HTML(paste0("<b>Please, enter performer's name first</b>"))})
                   }else if(switch(input$performer_type_1,
                                   "Musician" = switch(input$cooperation_form_1_1,
                                                       "None" = FALSE,
                                                       {"" %in% input$cooperator_name_1_1}),
                                   "Band" =  switch(input$cooperation_form_1_2,
                                                    "None" = FALSE,
                                                    {"" %in% input$cooperator_name_1_2}) # second warning
                   )){
                     output$text_info_1 <- shiny::renderText({HTML(paste0("<b>Please, enter cooperator's name first</b>"))})
                   }else{ # main work
                     df <- data.frame(performerType = input$performer_type_1,
                                      performerName = input$performer_name_1,
                                      cooperationForm = switch(input$performer_type_1,
                                                               "Musician" = input$cooperation_form_1_1,
                                                               "Band" = input$cooperation_form_1_2),
                                      cooperatorName = switch(input$performer_type_1,
                                                              "Musician" = switch(input$cooperation_form_1_1,
                                                                                  "None" = "None",
                                                                                  input$cooperator_name_1_1),
                                                              "Band" = switch(input$cooperation_form_1_2,
                                                                              "None" = "None",
                                                                              input$cooperator_name_1_2),
                                                              "None"),
                                      createdAt = as.character(Sys.time())
                     )
                     # mutual relation
                     if (input$performer_type_1 == "Musician" & input$cooperation_form_1_1 == coopCond[1]){
                       df <- dplyr::bind_rows(df,
                                              data.frame(performerType = "Musician",
                                                         performerName = input$cooperator_name_1_1,
                                                         cooperationForm = coopCond[1],
                                                         cooperatorName = input$performer_name_1,
                                                         createdAt = as.character(Sys.time())))

                     }
                     # mutual relation
                     if (input$performer_type_1 == "Band" & input$cooperation_form_1_2 == coopCond[2]){
                       df <- dplyr::bind_rows(df,
                                              data.frame(performerType = "Band",
                                                         performerName = input$cooperator_name_1_2,
                                                         cooperationForm = coopCond[2],
                                                         cooperatorName = input$performer_name_1,
                                                         createdAt = as.character(Sys.time())))

                     }    # new row(s) biding

                     insDf$df <- "if"(is.null(insDf$df),
                                      df,
                                      dplyr::bind_rows(insDf$df, df)
                     )

                     output$text_info_1 <- NULL

                     output$insertion_table_1 <- DT::renderDataTable({DT::datatable(insDf$df %>% rename_with(~settings$DTColumns) %>% dplyr::mutate(rowGroup = 1:dplyr::n()%% 2),
                                                                                    rownames = TRUE,
                                                                                    options = list(
                                                                                      pageLength = 20,
                                                                                      columnDefs = list(list(visible=FALSE,
                                                                                                             targets=6)
                                                                                      ))) %>% formatStyle(6,
                                                                                                          target='row',
                                                                                                          backgroundColor = styleEqual(c(1,0), settings$alternateColors))
                     }
                     )

                   }})
                 #### Data transfer


                 observeEvent(input$transmission_1, {
                   if(is.null(insDf$df)){
                     transmissionInfo <- HTML(paste0('<b>Please, insert data into table first</b>'))
                   }else{
                     export_data(conn=settings$myDB, data = insDf$df %>% select(-createdAt), my_table = settings$myTable, initial=FALSE)
                     output$insertion_table_1 <- NULL
                     insDf$df <- NULL
                     transmissionInfo <- HTML(paste0('<b>Data sent :)</b>'))
                     shinyWidgets::updatePickerInput(
                       session = parent_session,
                       "mod_2-performers_names_2",
                       choices = get_performers(settings$myDB, settings$my_table) %>% dplyr::group_by("performerType") %>% dplyr::group_split(),
                       clearOptions = TRUE
                     )
                   }
                   output$text_info_1 <- shiny::renderText({transmissionInfo})

                 })
               })}

