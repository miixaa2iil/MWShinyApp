mod_2_retrieve <- function(settings){
  ### UI
ui <- function(id){

    ns <- NS(id)

    tags$table(style = "width: 95%;",
               tags$tr(style = "height: 85%;",
                       tags$td(id = "left_2", ### input
                               h2(icon("gear"), "Settings"),
                               shinyWidgets::pickerInput(inputId = ns("musicians_names_2"),
                                                         label = "Select performers' names",
                                                         choices =  df2list(get_performers(conn=settings$myDB,
                                                                                           my_table = settings$myTable)) ,
                                                         multiple = TRUE,
                                                         options = list(`actions-box` = TRUE,
                                                                        `multiple-separator` = "*",
                                                                        `none-selected-text` = "No performer selected")
                               ),
                               shinyWidgets::actionBttn(inputId=ns("relations_2"),
                                                        label = "Retrieve relations",
                                                        style = "gradient",
                                                        color = "primary",
                                                        icon = icon("link")
                               ),
                               shinyBS::bsTooltip(ns("relations_2"), HTML(paste0("<b>After the selection click me",
                                                                                 br(),
                                                                                 "to retrieve performers", "&#39;", " relations :)</b>")),
                                                  "right", options = list(container = "body"))),
                       tags$td(id="right_2", ### output
                               DT::dataTableOutput(ns("relation_table_2")),
                               bsTooltip(ns("relation_table_2"),  HTML(paste0("<b>You can sort the table by columns, both increasingly and decreasingly.",
                                                                              br(),
                                                                              "Row filtering is also possible in the window ",
                                                                              "&#39;",
                                                                              "Search",
                                                                              "&#39;",
                                                                              "</b>")),
                                         "top", options = list(container = "body")),
                               h1(shiny::htmlOutput(ns("text_info_2")))
                       )))
  }

  ### SERVER

  server <- function(id){
    moduleServer(id,
                 function(input, output, session){

                   output$relation_table_2 <- NULL
                   output$text_info_2 <- NULL


                   ### Table creation
                   observeEvent(input$relations_2, {
                     if(is.null(input$performers_names_2)){
                       output$relation_table_2 <- NULL
                       output$text_info_2 <- shiny::renderText({HTML(paste0("<b>Please, select at least one performer</b>"))})
                     }else{
                       output$text_info_2 <- NULL
                       output$relation_table_2 <- DT::renderDataTable({DT::datatable(import_data(conn=settings$myDB,
                                                                                                 my_table = settings$myTable,
                                                                                                 performers_names = input$performers_names_2) %>% dplyr::group_by(`Selected type`, `Selected performer`) %>% dplyr::mutate(groupColor = (dplyr::cur_group_id()-1) %% settings$grColLen) %>% dplyr::ungroup(),
                                                                                 rownames = TRUE,
                                                                                 options = list(pageLength = 20,
                                                                                                columnDefs = list(list(visible=FALSE,
                                                                                                                       targets=5
                                                                                                )
                                                                                                )
                                                                                 )
                       )  %>% formatStyle(5,
                                          target='row',
                                          fontWeight = 'bold',
                                          backgroundColor = styleEqual(0:(settings$grColLen-1),
                                                                       settings$groupColors)
                       )
                       })
                     }

                   })
                   ###

                 }   )



    #

    }


  return(list(ui=ui, server=server))

}
