df2list <- function(df) {
  sapply(unique(df$performerType),
         function(ln) {
           df %>% filter(performerType == ln) %>% "[["("performerName") %>% as.list()
         },
         simplify = FALSE
  )
}
