get_performers <- function(conn, my_table){
  res <- RSQLite::dbGetQuery(conn,
                             paste0("SELECT DISTINCT performerType, performerName ",
                                    "FROM ",
                                    my_table,
                                    " ",
                                    "ORDER BY performerType, performerName"
                             ))

  return(res)
}
