import_data <- function(conn, my_table, performers_names){

  tmp_table <- "temp"

  df <- do.call(dplyr::bind_rows, lapply(names(performers_names),
                                         function(ln){
                                           perfVec <- unlist(performers_names[[ln]])
                                           data.frame(performerType = rep(ln,
                                                                          length(perfVec)),
                                                      performerName = perfVec)
                                         }
  )
  )

  RSQLite::dbWriteTable(conn, tmp_table, df)


  allSelMuscns <- unlist(performers_names$Musician)

  bandMuscns <- "if"(is.null(allSelMuscns),
                        data.frame(),
                        RSQLite::dbGetQuery(conn,
                                            paste0("SELECT performerName, ",
                                                   " cooperatorName ",
                                                   "FROM ",
                                                   my_table,
                                                   " ",
                                                   "WHERE performerName IN ('",
                                                   paste(allSelMuscns,
                                                         collapse = "', '"
                                                   ),
                                                   "') AND cooperationForm = 'Played in bandMuscns'"
                                            )))

  res <- dplyr::bind_rows(RSQLite::dbGetQuery(conn,
                                              paste0(
                                                "SELECT ",
                                                "mb.performerType AS 'st', ",
                                                "mb.performerName AS 'sp', ",
                                                "(CASE ",
                                                "WHEN cooperationForm = 'None' THEN 'No relation' ",
                                                "WHEN cooperationForm = 'Played in bandMuscns' THEN 'bandMuscns member'",
                                                "ELSE 'Joint performance' ",
                                                "END) AS 'r', ",
                                                "cooperatorName AS 'rp' ",
                                                "FROM ",
                                                my_table,
                                                " mb INNER JOIN ",
                                                tmp_table,
                                                " t on mb.performerType = t.performerType AND mb.performerName = t.performerName")),
                          "if"(nrow(bandMuscns) == 0, NULL,
                               {do.call(dplyr::bind_rows, apply(bandMuscns, 1, function(df){
                                 dplyr::bind_cols(data.frame(st = "Musician",
                                                             sp = df[1]),
                                                  RSQLite::dbGetQuery(conn,
                                                                      paste0("SELECT 'Same bandMuscns' AS 'r', ",
                                                                             "PerformerName as 'rp' ",
                                                                             "FROM ",
                                                                             my_table,
                                                                             " ",
                                                                             "WHERE cooperatorName = '",
                                                                             df[2],
                                                                             "' and performerName <> '",
                                                                             df[1],
                                                                             "'"))
                                 )}, simplify = FALSE))})
  ) %>% dplyr::arrange(st, sp, r, rp) %>% tibble::remove_rownames() %>% dplyr::rename(`Selected type` = st,
                                                                                      `Selected performer` = sp,
                                                                                      Relation = r,
                                                                                      `Related performer` = rp)
  RSQLite::dbExecute(conn,
                     paste0("DROP TABLE ",
                            tmp_table
                     )) # temp table deletion

  return(res)
}
